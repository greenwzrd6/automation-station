﻿DECLARE @AutomationId UNIQUEIDENTIFIER =
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaad';

-- AUTOMATION
INSERT INTO Automations
(
    Id,
    Name,
    Enabled,
    AutomationTriggerable
)
VALUES
(
    @AutomationId,
    'Create TOJ task when entity is placed in Released',
    1,
    1
);

-- WHEN
INSERT INTO AutomationTriggers
(
    Id,
    AutomationId,
    EventType,
    SourceSystem
)
VALUES
(
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbe',
    @AutomationId,
    'PlacementCreated',
    'Kanban'
);

-- CONDITION: entity placed in Released
INSERT INTO AutomationConditions
(
    Id,
    AutomationId,
    ConditionType,
    SourceSystem,
    ConfigurationJson
)
VALUES
(
    'cccccccc-cccc-cccc-cccc-cccccccccccf',
    @AutomationId,
    'ColumnEquals',
    'Kanban',
    '{
        "field": "payload.columnId",
        "operator": "Equals",
        "value": "22222222-2222-2222-2222-222222222232"
    }'
);

-- THEN: create a task in TOJ
INSERT INTO AutomationActions
(
    Id,
    AutomationId,
    ActionType,
    TargetSystem,
    ConfigurationJson,
    ExecutionOrder
)
VALUES
(
    'dddddddd-dddd-dddd-dddd-dddddddddde0',
    @AutomationId,
    'CreateTask',
    'TojSystem',
    '{
        "title": "Task created by Automation Station"
    }',
    0
);